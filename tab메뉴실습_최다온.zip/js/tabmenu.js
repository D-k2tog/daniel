$(function(){
    $(".panel> li:not("+$(".tab li a.selected").attr("href")+")").hide();
    
    $(".tab li a").click(function(){
      $(".tab li a").removeClass("selected");
      $(this).addClass("selected");
      $(".panel> li").hide();
      $($(this).attr("href")).show();
      return false; 
    });
  });
  