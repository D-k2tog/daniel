$(function() {
    // 메뉴 열기
    $(".hm").click(function() {
      $(".menu").animate({ right: "0%" }, 300);
    });
  
    // 메뉴 닫기
    $(".cross").click(function() {
      $(".menu").animate({ right: "-75%" }, 300);
    });
  
    // 서브메뉴 토글
    $(".menu > ul > li > a").click(function(e) {
      e.preventDefault(); // 링크 기본동작 방지
  
      if ($(this).next().is(":visible")) {
        $(this).next().stop().slideUp(500);
        $(this).children("img").attr("src", "img/ico_nav.png");
      } else {
        $(".sub").stop().slideUp(500);
        $(".menu > ul > li a").children("img").attr("src", "img/ico_nav.png");
        $(this).next().stop().slideDown(500);
        $(this).children("img").attr("src", "img/ico_nav_on.png");
      }
    });
  });
  