$(function(){
    function modalOn(){
        $(".modal_back").addClass("back_on");
    };
    function modalOff(){
        $(".modal_back").removeClass("back_on");
       
    };
   $(".hm").click(function(){
    modalOn();
   });
   $(".cross").click(function(){
    modalOff();
   });
    
    
});