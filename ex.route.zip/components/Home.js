function Home() {
  const exhibitions = [
    { id: 1, title: " 오늘의 기쁨", img: "img/E1.jpg" },
    { id: 2, title: "어린왕자의 별 이야기", img: "img/E2.jpg" },
    { id: 3, title: "호아킨 소로야", img: "img/E3.jpg" },
    { id: 4, title: "알렉스 키토 사진전", img: "img/E4.jpg" }
  ];

  const containerStyle = {
    padding: "20px",
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
    gap: "20px"
  };

  const cardStyle = {
    background: "#FBF3D1",
    color: "#1a1a1a",
    padding: "10px",
    borderRadius: "8px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
  };

  const imgStyle = {
    width: "100%",
    height: "auto",
    borderRadius: "8px"
  };

  return (
    <main style={{ padding: "20px" }}>
      <h2 style={{ marginBottom: "20px" }}>현재 진행 중인 전시</h2>
      <div style={containerStyle}>
        {exhibitions.map(exhibit => (
          <div key={exhibit.id} style={cardStyle}>
            <p>{exhibit.title}</p>
            <img src={exhibit.img} alt={exhibit.title} style={imgStyle} />
          </div>
        ))}
      </div>
    </main>
  );
}

window.Home = Home;
