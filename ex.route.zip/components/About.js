function About() {
  const exhibitions = [
    {
      id: 1,
      title: "오늘의 기쁨",
      desc:
        "일상에서 발견한 기쁨의 순간을 담은 전시입니다. 천의 겉면을 자르면 새로운 디자인이 나타나는 독창적인 텍스타일 작품 170여 점이 전시장에 펼쳐집니다. 섬세하고 유쾌한 표현으로 작가의 시선을 따라가며 작은 행복의 순간을 찾아보세요.",
      img: "img/E1.jpg"
    },
    {
      id: 2,
      title: "어린왕자의 별 이야기",
      desc:
        "상상력과 순수함이 어우러진 원작의 감동을 현대적 감각으로 재해석한 스토리 텔링형 미디어 전시입니다. 새롭게 구현한 우주의 공간들, 시공간을 넘나드는 연출. 지금껏 경험하지 못한 새로운 차원의 어린 왕자 이야기를 한 편의 영화처럼 온전히 느껴보세요.",
      img: "img/E2.jpg"
    },
    {
      id: 3,
      title: "호아킨 소로야",
      desc:
        "그가 불잡아둔 찬란한 순간들이 드디어 서울에서 펼쳐집니다. 인상주의와 자연주의 그 사이에서 그려낸 태양빛을 머금은 지중해 해변과 사랑하는 아내의 초상. 찰나를 영원으로 남기는 법을 알았던 그의 작품을 따라 우리의 일상 속에서 오래동안 반짝일 순간을 포착해보세요.",
      img: "img/E3.jpg"
    },
    {
      id: 4,
      title: "알렉스 키토 사진전",
      desc:
        "가벼운 산책, 새벽녘의 보랏빛 하늘, 자전거를 타던 주말 낮, 모든 형태의 달. 도시는 소란스럽고 마음은 늘 앞서가지만 어쩌면 가장 가까이에 있던 액자 없는 작품, '자연'. 지금 여기 당신이 미처 알아차리지 못했던 영화 같은 세상을 소개합니다.",
      img: "img/E4.jpg"
    }
  ];

  const containerStyle = {
    padding: "20px",
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "20px"
  };

  const cardStyle = {
    background: "#FBF3D1",
    color: "#1a1a1a",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
  };

  const imgStyle = {
    width: "100%",
    height: "auto",
    borderRadius: "8px",
    marginTop: "10px"
  };

  return (
    <section style={{ padding: "20px" }}>
      <h2 style={{ marginBottom: "20px" }}>전시 소개</h2>
      <div style={containerStyle}>
        {exhibitions.map(exhibit => (
          <div key={exhibit.id} style={cardStyle}>
            <h3>{exhibit.title}</h3>
            <p style={{ lineHeight: "1.5" }}>{exhibit.desc}</p>
            <img src={exhibit.img} alt={exhibit.title} style={imgStyle} />
          </div>
        ))}
      </div>
    </section>
  );
}

window.About = About;
