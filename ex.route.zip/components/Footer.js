function Footer() {
  return (
    <footer style={{
      background: '#FBF3D1',
      color: '#1a1a1a',
      padding: '20px',
      textAlign: 'center',
      borderTop: '1px solid #ddd'
    }}>
      <p>© 2025 My Website | 전시문의: info@mywebsite.com</p>
      <p>서울시 종로구 아트홀로 22 | 02-123-4567</p>
    </footer>
  );
}
window.Footer = Footer;
