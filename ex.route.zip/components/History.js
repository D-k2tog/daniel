function History() {
    const exhibitions = [
      {
        id: 1,
        title: "우연히 웨스 앤더슨2",
        desc:
          "이번 여정에서는 예상치 못한 순간들을 갑작스럽게 마주하고, 낯선 풍경 속에서 평소와는 다른 선택을 해야 할지도 모릅니다. 하지만 걱정 말고 찬찬히 저희의 가이드를 따라오다 보면 그동안 아쉽게 놓치고 있었던 아름답고 흥미로운 순간들을 새롭게 발견하게 될겁니다.",
        img: "img/P1.jpg"
      },
      {
        id: 2,
        title: "슈타이틀 북 컬처 | 매직 온 페이퍼",
        desc:
          "출판사 '슈타이들'을 이끄는 게르하르드 슈타이들이 고집스럽게 지켜오고 있는 종이책에 대한 '미친 열정'과 디테일에 집요하게 집착하는 완벽주의자의 '장인 정신'에 대한 이야기이기도 합니다.",
        img: "img/P2.png"
      },
      {
        id: 3,
        title: "반 고흐 인사이드: 러브, 빈센트",
        desc:
          "이번 작품은 그의 영혼의 절반이자. 평생에 걸친 후원자였던 동생 테오의 시점으로 흘러갑니다. 그가 사랑한 사람들, 도시, 색깔 인간 반 고흐의 원천이자 작품의 원동력이었던 그가 '사랑했던 것'들. 따뜻해서 더 아름다운 여정이 지금 시작됩니다",
        img: "img/P3.jpg"
      },
      {
        id: 4,
        title: "유토피아: 노웨어, 나우 히어",
        desc:
          "누구나 한 번쯤 유토피아를 꿈꾸지만, 그곳이 없다는 걸 알고 있습니다. 차가운 우주는 유토피아를 허용하지 않는다는 것도요. 우리는 생각해 보기로 합니다. 부서지는 햇살과 지는 노을, 파도 소리와 풀 냄새... 그저 바라다보니 선명해진 상상인지, 정말로 존재했던 곳은 아닐지",
        img: "img/P4.jpg"
      }
    ];
  
    const containerStyle = {
      padding: "20px",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
      gap: "20px"
    };
  
    const cardStyle = {
      background: "#FBF3D1",
      color: "#1a1a1a",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
    };
  
    const imgStyle = {
      width: "100%",
      height: "auto",
      borderRadius: "8px",
      marginTop: "10px"
    };
  
    return (
      <section style={{ padding: "20px" }}>
        <h2 style={{ marginBottom: "20px" }}>지난 전시 소개</h2>
        <div style={containerStyle}>
          {exhibitions.map(exhibit => (
            <div key={exhibit.id} style={cardStyle}>
              <h3>{exhibit.title}</h3>
              <p style={{ lineHeight: "1.5" }}>{exhibit.desc}</p>
              <img src={exhibit.img} alt={exhibit.title} style={imgStyle} />
            </div>
          ))}
        </div>
      </section>
    );
  }
  
  window.History = History;
  