function Header () {
    return (
        <header style={{ padding: '20px', background: '#FBF3D1' , color: '#1a1a1a' }}>
            <h1>
                <a href="index.html" style={{ color:'#1a1a1a', textDecoration: 'none' }}>
                    My Website
                </a>
            </h1>
        </header>
    );
}
window.Header = Header;
//외부 js로 로드할 수 있게 window에 등록