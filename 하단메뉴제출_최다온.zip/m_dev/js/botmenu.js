$(function(){
    let lastScrollTop = 0; //마지막 스크롤 위치를 저장하는 변수
    const delta = 5;
    const $fixBox = $('.bottomNav');
    const fixBoxHeight = $fixBox.outerHeight();
    let didScroll = false;  //스크롤이 발생했는지를 표시하는 플래그

    // 스크롤 이벤트 발생 시 플래그 변경
    $(window).on('scroll', function() {
        didScroll = true;
      });

     // 250ms마다 스크롤 감지
    setInterval(function() {
        if (didScroll) {
          hasScrolled();
          didScroll = false; //didScroll을 false로 리셋
        }
      }, 250); 

      function hasScrolled() {
        const nowScrollTop = $(this).scrollTop(); //현재 스크롤 위치
        if (Math.abs(lastScrollTop - nowScrollTop) <= delta) {
            return; // 스크롤 차이가 delta 이하라면 아무 작업도 하지 않음
          }

           // 아래로 스크롤 & 요소 높이 이상 스크롤했을 때 숨김
          if (nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight) {
            $fixBox.removeClass('show');
          } else {
            // 위로 스크롤 중 & 아직 문서 끝 도달 전 → 보임
            // 스크롤이 올라갔고, 화면 끝에 도달하지 않았다면 bottomNav 보임
            if (nowScrollTop + $(window).height() < $(document).height()) {
              $fixBox.addClass('show');
            }
          }
          lastScrollTop = nowScrollTop;
          // lastScrollTop을 현재 위치로 갱신
          //현재 스크롤 위치를 저장해, 다음 비교에 사용
      }
});

